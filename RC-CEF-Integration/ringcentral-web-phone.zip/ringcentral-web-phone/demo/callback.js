require('ringcentral').handleLoginRedirect();
